/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serializacaomensagem;

import java.io.Serializable;
import java.util.LinkedList;

/**
 *
 * @author 20161bsi0349
 */
public class Usuario implements Serializable{
    
    private String nome;
    private LinkedList<Mensagem> enviadas = new LinkedList<>();
    private LinkedList<Mensagem> recebidas = new LinkedList<>();

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the enviadas
     */
    public LinkedList<Mensagem> getEnviadas() {
        return enviadas;
    }

    /**
     * @param enviadas the enviadas to set
     */
    public void setEnviadas(LinkedList<Mensagem> enviadas) {
        this.enviadas = enviadas;
    }

    /**
     * @return the recebidas
     */
    public LinkedList<Mensagem> getRecebidas() {
        return recebidas;
    }

    /**
     * @param recebidas the recebidas to set
     */
    public void setRecebidas(LinkedList<Mensagem> recebidas) {
        this.recebidas = recebidas;
    }
}
