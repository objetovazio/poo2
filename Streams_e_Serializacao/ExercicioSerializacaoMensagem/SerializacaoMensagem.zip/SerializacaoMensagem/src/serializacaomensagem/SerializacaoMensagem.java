/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serializacaomensagem;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;

/**
 *
 * @author 20161bsi0349
 */
public class SerializacaoMensagem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Usuario user = new Usuario();
        Usuario user2 = new Usuario();

        user.setNome("André");
        user2.setNome("Alguém");

        //Cria mensagem 1
        Mensagem mensagem = new Mensagem();
        mensagem.setTexto("Olá, como vai você?");

        //Cria resposta
        Mensagem resposta = new Mensagem();
        mensagem.setTexto("Vou bem, e você? :)");

        //Liga resposta à mensagem que foi respondida
        resposta.setMensagem(mensagem);

        //Guarda a mensagem enviadas pelo user
        user.getEnviadas().add(mensagem);
        user.getRecebidas().add(resposta);

        //Guarda a mensagem enviada pelo user2
        user2.getRecebidas().add(mensagem);
        user2.getEnviadas().add(resposta);

        salvarObj(user, user2);

        
        Usuario[] usersRead= readObj();
        
        Usuario usuarioSalvo1 = usersRead[0];
        Usuario usuarioSalvo2 = usersRead[1];
        
        System.out.println(usuarioSalvo1.getNome() + ": " + usuarioSalvo1.getEnviadas().get(0).getTexto());
        System.out.println(usuarioSalvo2.getNome() + ": " + usuarioSalvo1.getEnviadas().get(0).getTexto());

    }

    private static Usuario[] readObj() {
        Usuario[] users = new Usuario[2];
        
        try {
            String current = new java.io.File(".").getCanonicalPath();
            FileInputStream fileIn = new FileInputStream(current + "\\src\\usuario_serializado.user");
            ObjectInputStream objectIn = new ObjectInputStream(fileIn);
            
            users[0] = (Usuario) objectIn.readObject();
            users[1] = (Usuario) objectIn.readObject();
            
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        
        return users;
    }

    private static void salvarObj(Usuario user, Usuario user2) {
        try {
            String current = new java.io.File(".").getCanonicalPath();
            FileOutputStream fileOut = new FileOutputStream(current + "\\src\\usuario_serializado.user");
            ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);

            objectOut.writeObject(user);
            objectOut.writeObject(user2);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
