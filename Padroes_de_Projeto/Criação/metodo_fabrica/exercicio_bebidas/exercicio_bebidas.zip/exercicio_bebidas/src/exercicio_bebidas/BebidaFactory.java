/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio_bebidas;

import java.lang.reflect.Method;

/**
 *
 * @author 20161bsi0349
 */
public class BebidaFactory {
    
    public static Bebida createBebida(String classe){
        Object classReflection = null;
        
        try{
            classReflection = Class.forName(classe).newInstance();
        }
        catch(ClassNotFoundException | IllegalAccessException | InstantiationException e){
            e.printStackTrace();
        }
        
        return (Bebida)classReflection;
    }
    
}
