/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio_bebidas;

/**
 *
 * @author 20161bsi0349
 */
public class StoresBebidas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Bebida b1 = BebidaFactory.createBebida("exercicio_bebidas.Cha");
        
        System.err.println("Adoro beber " + b1.getDrink());
        
    }
    
}
