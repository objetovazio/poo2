/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 20161bsi0349
 */
public class StatusItem {
    
    public enum Estado {CARRINHO, FECHADO, ENVIADO, ENTREGUE, PAGO};
    private Estado estado;
    private boolean podeCancelar;
    private boolean compraConcluida;
    
    /**
     * Construtor
     * @param estado
     * @param podeCancelar
     * @param compraConcluida 
     */
    public StatusItem(Estado estado, boolean podeCancelar, boolean compraConcluida){
        this.setEstado(estado);
        this.podeCancelar = podeCancelar;
        this.compraConcluida = compraConcluida;
    }
    
    /**
     * @return the estado
     */
    public Estado getEstado() {
        return estado;
    }

    /**
     * @param estado the estado to set
     */
    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    /**
     * @return the podeCancelar
     */
    public boolean isPodeCancelar() {
        return podeCancelar;
    }

    /**
     * @param podeCancelar the podeCancelar to set
     */
    public void setPodeCancelar(boolean podeCancelar) {
        this.podeCancelar = podeCancelar;
    }

    /**
     * @return the compraConcluida
     */
    public boolean isCompraConcluida() {
        return compraConcluida;
    }

    /**
     * @param compraConcluida the compraConcluida to set
     */
    public void setCompraConcluida(boolean compraConcluida) {
        this.compraConcluida = compraConcluida;
    }
    
    
}
