
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 20161bsi0349
 */
public class Pedido {
         
    private ArrayList<Item> itensPedido = new ArrayList();

    /**
     * @return the itensPedido
     */
    public ArrayList<Item> getItensPedido() {
        return itensPedido;
    }

    /**
     * @param itensPedido the itensPedido to set
     */
    public void setItensPedido(ArrayList<Item> itensPedido) {
        this.itensPedido = itensPedido;
    }
    
    
    
    
}
