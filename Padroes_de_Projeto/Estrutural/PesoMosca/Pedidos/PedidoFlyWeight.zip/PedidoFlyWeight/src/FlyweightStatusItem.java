
import java.util.HashMap;
import jdk.nashorn.internal.ir.Flags;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 20161bsi0349
 */
public class FlyweightStatusItem {
    private static HashMap<StatusItem.Estado, StatusItem> MapStatus = new HashMap<StatusItem.Estado, StatusItem>();
    
    public FlyweightStatusItem(){
        this.MapStatus.put(StatusItem.Estado.CARRINHO, new StatusItem(StatusItem.Estado.CARRINHO, true, false));
        this.MapStatus.put(StatusItem.Estado.FECHADO, new StatusItem(StatusItem.Estado.FECHADO, true, false));
        this.MapStatus.put(StatusItem.Estado.PAGO, new StatusItem(StatusItem.Estado.PAGO, true, true));
        this.MapStatus.put(StatusItem.Estado.ENVIADO, new StatusItem(StatusItem.Estado.ENVIADO, false, true));
        this.MapStatus.put(StatusItem.Estado.ENTREGUE, new StatusItem(StatusItem.Estado.ENTREGUE, false, true));
    }
    
    public static StatusItem get(StatusItem.Estado estado){
         return MapStatus.get(estado);
    }
}
