/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tvfacade;

/**
 *
 * @author 20161bsi0349
 */
public class ControleVideo {
    
    private boolean isOn = false;
    
    public void aumentarContraste(){
        System.out.println("aumentar Contraste");
    }
    
    public void diminuirContraste(){
        System.out.println("diminuir Contraste");
    }
    
    public void aumentarBrilho(){
        System.out.println("aumentar Brilho");
    }
    
    public void diminuirBrilho(){
        System.out.println("diminuir Brilho");
    }
    
    public void turnOnOff(){
        if(isOn){
            System.out.println("Desligando...");
            isOn = false;
        }
        else {
            System.out.println("Ligando...");
            isOn = true;
        }
    }
}
