/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tvfacade;

/**
 *
 * @author 20161bsi0349
 */
public class ControleRemotoFachada {
    private ControleSom controleSom;
    private ControleCanal controleCanal;
    private ControleVideo controleVideo;
    
    public ControleRemotoFachada(){
        controleSom = new ControleSom();
        controleCanal = new ControleCanal();
        controleVideo = new ControleVideo();
    }
    
    public void volume(boolean aumentar){
        if(aumentar) 
            controleSom.aumentar();
        else
            controleSom.dimuir();
    }
    
    public void mute(){
        controleSom.mudo();
    }
    
    public void avancarCanal(){
        controleCanal.avancarCanal();
    }
    
    public void voltarCanal(){
        controleCanal.voltarCanal();
    }
    
    public void selecionarFavorito(){
        controleCanal.selecionarFavorito();
    }
    
    public void brilho(boolean aumentar){
        if(aumentar) controleVideo.aumentarBrilho();
        else controleVideo.diminuirBrilho();
    }
    
    public void contraste(boolean aumentar){
        if(aumentar) controleVideo.aumentarContraste();
        else controleVideo.diminuirContraste();
    }
    
    public void ligarDesligar(){
        controleVideo.turnOnOff();
    }
}
