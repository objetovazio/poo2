/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grupoemail;

/**
 *
 * @author 20161bsi0349
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        CaixaEntradaGrupo caixaEntradaGrupo = new CaixaEntradaGrupo();
        
        caixaEntradaGrupo.addObserver(new MembroEmail("ifes@teste.com.br"));
        caixaEntradaGrupo.addObserver(new MembroWhatsApp(999999999));
        
        caixaEntradaGrupo.setMensagem("Mensagem 1");
        caixaEntradaGrupo.setMensagem("Mensagem 2");
        caixaEntradaGrupo.setMensagem("Mensagem 3");
    }
    
}
