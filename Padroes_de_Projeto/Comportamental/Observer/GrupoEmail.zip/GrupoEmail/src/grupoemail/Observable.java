/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grupoemail;

import java.util.ArrayList;

/**
 *
 * @author 20161bsi0349
 */
public class Observable {
    protected ArrayList<Observer> listObserver;
    
    public Observable(){
        listObserver = new ArrayList<>();
    }
    
    public void addObserver(Observer obs){
        getListObserver().add(obs);
    }
    
    public void deleteObserver(Observer obs){
        getListObserver().remove(obs);
    }

    /**
     * @return the listObserver
     */
    public ArrayList<Observer> getListObserver() {
        return listObserver;
    }

    /**
     * @param listObserver the listObserver to set
     */
    public void setListObserver(ArrayList<Observer> listObserver) {
        this.listObserver = listObserver;
    }
    
    public void notificar(){
        for(Observer ob : listObserver){
            ob.update(this);
        }
        System.out.println("");
    }
}
