/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grupoemail;

/**
 *
 * @author 20161bsi0349
 */
public class MembroWhatsApp implements Observer{

    private int numero;

    public MembroWhatsApp(int numero){
        this.numero = numero;
    }
    
    /**
     * @return the numero
     */
    public int getNumero() {
        return numero;
    }

    /**
     * @param numero the numero to set
     */
    public void setNumero(int numero) {
        this.numero = numero;
    }

    @Override
    public void update(Observable obs) {
        System.out.println("Uma nova mensagem recebida no WhatsApp: " + ((CaixaEntradaGrupo)obs).getMensagem() + " para o numero " + numero);
    }
    
}
