/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grupoemail;

/**
 *
 * @author 20161bsi0349
 */
public class CaixaEntradaGrupo extends Observable {
    
    private String mensagem;
    
    public CaixaEntradaGrupo(){
        super();
    }

    /**
     * @param mensagem the mensagem to set
     */
    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
        this.notificar();
    }

    /**
     * @return the mensagem
     */
    public String getMensagem() {
        return mensagem;
    }
    
}
